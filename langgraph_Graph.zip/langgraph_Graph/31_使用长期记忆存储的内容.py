
from langchain_core.messages import ToolMessage
from langgraph import graph
from langgraph.store.postgres import PostgresStore
from typing import Final, Tuple, Literal
from langchain.messages import SystemMessage, HumanMessage, AIMessage
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.graph import StateGraph, START, END, MessagesState
from langchain_openai import ChatOpenAI
from langgraph.runtime import Runtime


USER_NS: Final[Tuple[str]] = ("users",)  # 构建用户命名空间，用于存储用户相关的永久记忆
PREFERENCES_KEY: Final[str] = "preferences"  # 构建用户偏好键，用于存储用户偏好
DB_URL = "postgresql://my_langgraph_user:123456@localhost:5432/langgraph_db?sslmode=disable"


model = ChatOpenAI(
    model="qwen3-max-preview",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7,
    extra_body={
        "enable_thinking": False,  # 硬关思考链（Qwen 混合模型标准开关）
        # "reasoning": {"effort": "none"},  # 新接口也可用这个，二选一
    },
)

class OverAllState(MessagesState):  # MessagesState内部使用的是add_messages方法，根据id来判断是否覆盖还是追加
    username: str
    user_input: str
    output: str
    preferences: dict[str, str]

"""
因为 checkpointer 把第一次运行后的 preferences 存进了 checkpoint，第二次 graph.invoke() 时，LangGraph 自动帮你恢复了 State，所以 state.get("preferences") 不再为空
"""
# 路由函数，如果状态中没有用户偏好，就从数据库中获取，否则直接执行LLM生成输出
def router(state: OverAllState) -> Literal["check_preferences_node", "llm_node"]:
    if not state.get("preferences"):
        print("用户偏好为空，需要从长期记忆数据库中获取")
        return "check_preferences_node"
    else:
        print("用户偏好不为空，直接执行LLM生成输出")
        return "llm_node"

# 检查长期记忆数据库中是否有用户偏好
def check_preferences_node(state: OverAllState,runtime:Runtime) -> OverAllState:
    print("从长期记忆数据库中获取用户偏好")
    #拼接命名空间
    namespace = (*USER_NS, state["username"])
    #获取长期记忆数据库中的用户偏好
    run_store = runtime.store                  # 从runtime中获取store对象
    run_item = run_store.get(namespace, PREFERENCES_KEY)

    if not run_item:
        print("{}用户偏好为空".format(state["username"]))
        return {}
    else:
        print("{}用户偏好不为空，爱好为{}".format(state["username"], run_item.value))
        return {"preferences": run_item.value}

def llm_node(state: OverAllState) -> OverAllState:
    print("NODE llm_node 执行执行LLM生成输出")
    #检查是否存在长期记忆数据库中的用户偏好
    if not state.get("preferences"):
        print("NODE llm_node 执行用户偏好为空，需要从数据库中获取")
        return "check_preferences_node"
    else:
        print("NODE llm_node 执行用户偏好不为空，直接执行LLM生成输出")
    # 执行LLM生成输出
    human_prompt = (f"这里是用户的偏好：{state['preferences']}\n，这里是用户的输入：{state['user_input']}")
    system_prompt = (f"你是一个专业的助手，你的任务是根据用户的偏好和输入，生成符合用户偏好的输出。")

    messages:list[SystemMessage|HumanMessage|AIMessage|ToolMessage] = [SystemMessage(content=system_prompt)] if not state.get("messages", []) else state["messages"]

    response =  model.invoke(messages+[HumanMessage(content=human_prompt)])
    output = response.content
    return {
        "messages": messages+[HumanMessage(content=human_prompt),AIMessage(content=output)], # 追加用户输入和AI助手输出
        "output": output
    }


#构建状态图
builder = StateGraph(OverAllState)
builder.add_node("check_preferences_node", check_preferences_node)
builder.add_node("llm_node", llm_node)

builder.add_conditional_edges(START, router, path_map=["check_preferences_node", "llm_node"])
builder.add_edge("check_preferences_node","llm_node")
builder.add_edge("llm_node", END)

#构建长期记忆和短期记忆 store和checkpointer
with (PostgresStore.from_conn_string(DB_URL) as store,\
      PostgresSaver.from_conn_string(DB_URL) as checkpointer):
    checkpointer.setup()
    store.setup()

    graph = builder.compile(store=store, checkpointer=checkpointer)  # 全部加入

    config = {
        "configurable":{
            "thread_id":"TEST037"
        }
    }
    res = graph.invoke({"username":"JM","user_input":"我的爱好有哪些，周末你推荐我做一些什么"},config=config)
    print("="*20)
    print(res)
