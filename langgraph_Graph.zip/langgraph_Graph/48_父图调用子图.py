from typing import TypedDict
from langgraph.graph import StateGraph, START, END

#1. 构建子图
#1.1 声明子图的状态
class SubgraphState(TypedDict):
    raw_text:str #未清洗的文本
    stripped_text:str  # 去除首位的空格
    punctuated:str  # 句尾添加句号

#1.2 声明子图的节点
def subgraph_strip_node(state:SubgraphState) -> SubgraphState:
    print("正在调用子图节点subgraph_strip_node")
    raw_text = state["raw_text"]
    stripped_text = raw_text.strip()
    return {
        "stripped_text":stripped_text
    }

# 添加句号的节点
def subgraph_punctuate_node(state:SubgraphState) -> SubgraphState:
    print("正在调用子图节点subgraph_punctuate_node")
    stripped_text = state["stripped_text"]
    punctuated = stripped_text + "."
    return {
        "punctuated":punctuated
    }

#2. 构建子图
builder = StateGraph(SubgraphState)
builder.add_node("subgraph_punctuate_node", subgraph_punctuate_node)
builder.add_node("subgraph_strip_node", subgraph_strip_node)

builder.add_edge(START, "subgraph_strip_node")
builder.add_edge("subgraph_strip_node", "subgraph_punctuate_node")
builder.add_edge("subgraph_punctuate_node", END)

subgraph_graph = builder.compile()

# res = subgraph_graph.invoke({"raw_text":" 你好  "})
# print(res)


#3. 构建父图
class ParentState(TypedDict):
    input_text:str #未清洗的文本
    output_text:str  # 句尾添加句号

#3.1 声明父图的节点
def parent_node(state:ParentState) -> ParentState:
    print("正在调用父图节点parent_node")
    input_text = state["input_text"]
    res = subgraph_graph.invoke({"raw_text":input_text})
    clear_text = res["punctuated"]
    return {
        "output_text":clear_text
    }


builder = StateGraph(ParentState)
builder.add_node("parent_node", parent_node)

builder.add_edge(START, "parent_node")
builder.add_edge("parent_node", END)
parent_graph = builder.compile()

res = parent_graph.invoke({"input_text":" 你好, 我是JM啊啊啊啊啊啊啊  "})
print(res)


png_bytes = parent_graph.get_graph(xray=True).draw_mermaid_png()   # 添加xray=True可以查看子图的节点！！！！！！！！！！！！！！
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")
