from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, START, END
from langgraph.types import Send
from langgraph.graph.message import MessagesState
from langchain_openai import ChatOpenAI
from typing import TypedDict, Literal, Sequence
CONTENT_TYPES = ["poem", "joke", "ci_poem"]
model = ChatOpenAI(
    model="qwen3.7-plus",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7,
)

class OverAllState(MessagesState):  # MessagesState内部使用的是add_messages方法，根据id来判断是否覆盖还是追加
    topic: str
    poem: str
    joke: str
    ci_poem: str
    content_type: str

# 私有状态
class workerState(TypedDict):
    content_type: Literal["poem", "joke","ci_poem"]
    prompt: str

class inputState(TypedDict):
    topic: str

class outputState(TypedDict):
    poem: str
    joke: str
    ci_poem: str

def worker_node(state: workerState) -> outputState:
    content_type = state["content_type"]
    prompt = state["prompt"]
    content = model.invoke([HumanMessage(prompt)]).content
    return {
        content_type: content  # worker_node 的返回值，按 key 合并到 OverAllState
    }

def router(state:inputState) -> Sequence[Send]:
    router_prompt = "请生成关于{} 的 {}"
    english2Chinese = {
        "poem": "七言绝句",
        "joke": "笑话",
        "ci_poem": "中文词"
    }
    topic = state["topic"]
    return [
        Send(   # 动态地向某个节点发送一条“私有子任务”
            "worker_node",
            {
                "content_type": content_type,
                "prompt": router_prompt.format(topic,
                english2Chinese[content_type])
            }
        )
        for content_type in CONTENT_TYPES
    ]

# 4. 构建图
builder = StateGraph(
    state_schema=OverAllState,
    input_schema=inputState,
    output_schema=outputState)

builder.add_node("worker_node", worker_node)

builder.add_conditional_edges(START,router,path_map=["worker_node"])
builder.add_edge("worker_node", END)



# 5. 编译运行
graph = builder.compile()
result = graph.invoke(inputState({"topic": "荷花"}))
print(result)

# 7.保存图片
png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")