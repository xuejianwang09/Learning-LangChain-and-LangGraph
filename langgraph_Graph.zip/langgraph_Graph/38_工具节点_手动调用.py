from json import tool
from typing import TypedDict, Literal

from langchain_core.messages import HumanMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START, END, MessagesState
from langgraph.types import Command, interrupt
from pydantic import BaseModel, Field
from langchain_tavily import TavilySearch
from langchain.tools import tool
from langchain.agents import create_agent
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage, ToolMessage
from dotenv import load_dotenv


model = ChatOpenAI(
    model="qwen3.7-plus",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7,
)

@tool(parse_docstring=True)
def get_weather(city: str) -> str:
    """
    查询指定城市的当日天气

    Args:
        city: 要查询天气的城市名称，如"北京"、"上海"

    Returns:
        该城市的当日天气描述
    """
    return f"{city} 当日的天气为晴朗"

@tool(parse_docstring=True)
def get_news(home_or_abroad: bool) -> str:
    """
    查询国内外的新闻

    Args:
        home_or_abroad: 查询国内或者国外的新闻 True:国内新闻 False:国外新闻
    """
    if home_or_abroad:
        return "Kimi 新模型发布"
    return "Anthropic 暂停模型访问"

#模型绑定工具
tools_by_name = {
    "get_weather":get_weather,
    "get_news":get_news
}

tools = [get_weather,get_news]

model_with_tools = model.bind_tools(tools=tools)

#3. 声明状态 -> 传入的时候 直接写入HumanMessage
class OverAllState(MessagesState):
    output:str

#4. 定义节点
def llm_node(state:OverAllState) -> OverAllState:
    msg = state["messages"]
    # 调用大模型
    res = model_with_tools.invoke(msg)
    return {
        "messages":[res],
        "output": res.content
    }

def tool_node(state:OverAllState) -> OverAllState:
    messages = state["messages"]
    last_message = messages[-1]
    
    # 执行工具调用
    tool_messages = []
    for tool_call in last_message.tool_calls:
        tool_name = tool_call["name"]
        tool_args = tool_call["args"]
        tool_id = tool_call["id"]
        
        # 根据工具名称找到对应的工具函数并执行
        tool_func = tools_by_name[tool_name]
        tool_result = tool_func.invoke(tool_args)
        
        # 创建 ToolMessage
        tool_messages.append(
            ToolMessage(name = tool_name, content=str(tool_result), tool_call_id=tool_id)
        )
    
    return {
        "messages": tool_messages
    }

def router(state:OverAllState) -> Literal["tool_node",END]:
    if state["messages"][-1].tool_calls:
        return "tool_node"
    return END

#5. 构建图
builder = StateGraph(state_schema=OverAllState)
builder.add_node("llm_node",llm_node)
builder.add_node("tool_node",tool_node)

builder.add_edge(START,"llm_node")
builder.add_conditional_edges("llm_node", router, path_map=["tool_node",END])
builder.add_edge("tool_node","llm_node")

graph = builder.compile()

res = graph.invoke({"messages":[HumanMessage(content="查询一下今天上海的天气,和国内的新闻")]})

for msg in res["messages"]:
    msg.pretty_print()