from idlelib import history
from pydoc_data import topics

from langchain_core.messages import HumanMessage
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import MessagesState
from langchain_openai import ChatOpenAI

model = ChatOpenAI(
    model="qwen3.7-plus",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7,
    extra_body={
        "enable_thinking": False,   # 硬关思考链（Qwen 混合模型标准开关）
        # "reasoning": {"effort": "none"},  # 新接口也可用这个，二选一
    },
)

class OverAllState(MessagesState):  # MessagesState内部使用的是add_messages方法，根据id来判断是否覆盖还是追加
    topic: str
    poem: str
    joke: str
    final_output: str

class InputState(MessagesState):
    topic: str

class OutputState(MessagesState):
    final_output: str

def node_poem(state: InputState) -> OverAllState:
    print("正在执行node_poem！！！！！！！！！！！！")
    topic: str = state["topic"]
    res = model.invoke([HumanMessage(f"写一首关于{topic}的诗")])
    return {
        "poem": res,
    }

def node_joke(state: InputState) -> OverAllState:
    print("正在执行node_joke！！！！！！！！！！！！")
    topic: str = state["topic"]
    res = model.invoke([HumanMessage(f"写一个关于{topic}的笑话")])
    return {
        "joke": res,
    }

def node_output(state: OverAllState) -> OutputState:
    print("正在执行node_output！！！！！！！！！！！！")
    topic = state["topic"]
    poem = state["poem"]
    joke = state["joke"]
    final_output = f"{topic}的诗是：{poem}\n{topic}的笑话是：{joke}"
    return {
        "final_output": final_output,
    }


# 构建图
builder = StateGraph(state_schema=OverAllState,input_schema=InputState,output_schema=OutputState)

builder.add_node("output_node",node_output)
builder.add_node("node_poem",node_poem)
builder.add_node("node_joke",node_joke)

builder.add_edge(START, "node_poem")
builder.add_edge(START, "node_joke")
builder.add_edge("node_poem", "output_node")
builder.add_edge("node_joke", "output_node")
builder.add_edge("output_node", END)

# 配置检查点
DB_URL = "postgresql://my_langgraph_user:123456@localhost:5432/langgraph_db?sslmode=disable"

with PostgresSaver.from_conn_string(DB_URL) as checkpointer:  # 第一次使用 需要setup数据库
    checkpointer.setup()
    graph = builder.compile(checkpointer = checkpointer)

    # 配置线程id
    config = {
        "configurable":{
            "thread_id":"TEST004"
        }
    }
    # result = graph.invoke({"messages": [HumanMessage("你好，我是JM")]},config = config)
    # print(result)

    result = graph.invoke({"topic": "狗"},config = config)
    print(result)

    png_bytes = graph.get_graph().draw_mermaid_png()
    with open("mermaid_graph.png", "wb") as f:
        f.write(png_bytes)
    print("图片已保存为 mermaid_graph.png")

    # 查看历史检查点
    # history_checkpoints1 = checkpointer.list(config)
    # print(history_checkpoints1)

    print("-----------------")

    # 查看历史检查点 get_state_history
    history_checkpoints2 = list(graph.get_state_history(config))
    print(history_checkpoints2)

    # 获取最新的检查点
    last_history_checkpoint = graph.get_state(config)
    print(last_history_checkpoint)

    #查询指定检查点
    target_config = {
        "configurable":{
            "thread_id":"TEST003",
            # "checkpoint_ns":"",  检查点命名空间，默认值为空字符串
            "checkpoint_id":"1f1915b8-e814-6a44-8002-20a765b90bc2"
        }
    }
    target_checkpoint = graph.get_state(config=target_config)
    print(target_checkpoint)
