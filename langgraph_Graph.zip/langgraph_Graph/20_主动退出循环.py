from langchain_core.runnables import RunnableConfig
from langgraph.managed import RemainingSteps
from langgraph.graph import StateGraph, START, END
from typing import TypedDict, Literal
from loguru import logger


# 1. 声明状态
class OverAllState(TypedDict):
    remaining_steps: RemainingSteps


# 2. 声明循环节点
def loop_node(state: OverAllState, config: RunnableConfig) -> OverAllState:
    cur_step = config["metadata"]["langgraph_step"]
    remaining_steps = state["remaining_steps"]
    logger.info("loop_node, cur_step: {}, remaining_step: {}", cur_step, remaining_steps)
    return {}

# 添加路由节点
def route_node(state: OverAllState) -> Literal["loop_node", END]:
    remaining_steps = state["remaining_steps"]
    if remaining_steps <3 and remaining_steps > 0:  # 当前剩余步数在1-2之间，退出循环
        logger.info("当前循环步数在1-2之间，退出循环")
        return END
    else:
        return "loop_node"

# 3. 构建图
builder = StateGraph(OverAllState)

builder.add_node("loop_node", loop_node)

builder.add_edge(START, "loop_node")
builder.add_conditional_edges("loop_node", route_node)

# 4. 编译
graph = builder.compile()

# 5. 运行
config = {
    "recursion_limit": 10  # 控制最大步数  如果超出最大步数 会抛出异常 被动退出 不优雅
}

result = graph.invoke({}, config=config)
print(result)

# 7.保存图片
png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")