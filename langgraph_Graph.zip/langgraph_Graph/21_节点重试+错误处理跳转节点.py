from langgraph.types import Command, RetryPolicy
from langgraph.graph import StateGraph, START, END
from loguru import logger
from requests import HTTPError
from typing import TypedDict, Literal

# 1. 状态
class EmptyState(TypedDict):
    pass

# 2. 节点函数
def node_a(state: EmptyState) -> EmptyState:
    logger.info("node_a 正在运行")
    raise HTTPError("模拟HTTP错误")
    # return state

def node_b(state: EmptyState) -> EmptyState:
    logger.info("node_b 正在运行")
    return state

def output_node(state: EmptyState) -> EmptyState:
    logger.info("output_node 收到最终状态")
    return state

# 3. 正确的 error_handler（只接收 error 参数）
def handle_error(
    error: Exception,
) -> Command[Literal["output_node"]]:
    logger.error(f"捕获到异常错误信息: {error}，跳转至 output_node")
    return Command(goto="output_node")

# 4. 构建图
builder = StateGraph(state_schema=EmptyState)

builder.add_node(
    "node_a",
    node_a,
    retry_policy=RetryPolicy(
        max_attempts=3,
        initial_interval=0.5,
        backoff_factor=2,
        max_interval=10,
        jitter=True,
    ),
    error_handler=handle_error,
)

builder.add_node("node_b", node_b)
builder.add_node("output_node", output_node)

builder.add_edge(START, "node_a")

"""
关键：用 conditional_edges，而不是 add_edge("node_a", "node_b")
因为 add_edge("node_a", "node_b") 表示“无论如何，node_a 之后一定去 node_b
而 conditional_edges 表示“node_a 结束后，由我来决定下一步去哪”
"""
def after_node_a(state: EmptyState) -> Literal["node_b", "output_node"]:
    """
    如果 error_handler 没有接管，就走 node_b
    （error_handler 已接管的情况不会走到这里）
    """
    return "node_b"

builder.add_conditional_edges("node_a", after_node_a)
builder.add_edge("node_b", "output_node")
builder.add_edge("output_node", END)

graph = builder.compile()

# 5. 执行
result = graph.invoke({})
logger.info(f"最终结果: {result}")

# 7.保存图片
png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")