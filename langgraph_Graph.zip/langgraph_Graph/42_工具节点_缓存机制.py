
from typing import TypedDict, Literal

import json
from langgraph.graph import StateGraph, START, END, MessagesState
from langgraph.prebuilt import ToolNode
from langchain.tools import tool
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage, ToolMessage
import random
from dataclasses import dataclass

from loguru import logger

model = ChatOpenAI(
    model="qwen3.7-plus",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7,
)


@tool(parse_docstring=True)
def get_weather(city: str) -> str:
    """
    查询指定城市的当日天气

    Args:
        city: 要查询天气的城市名称，如"北京"、"上海"

    Returns:
        该城市的当日天气描述
    """
    print("//////////////////工具被调用一次 get_weather/////////////////")
    return f"{city} 当日的天气为晴朗"


tools = [get_weather]
model_with_tools = model.bind_tools(tools=tools)


# 3. 声明状态 -> 传入的时候 直接写入HumanMessage
class OverAllState(MessagesState):
    output: str


# 4. 定义节点
def llm_node(state: OverAllState) -> OverAllState:
    msg = state["messages"]
    # 调用大模型
    res = model_with_tools.invoke(msg)
    return {
        "messages": [res],
        "output": res.content
    }


def router(state: OverAllState) -> Literal["tool_node", END]:
    if state["messages"][-1].tool_calls:
        return "tool_node"
    return END


#4. 定义工具调用包装器 实现缓存机制
global_cache = dict()
def wrap_tool_call(request,execute):
    tool_name = request.tool_call["name"]
    tool_args = json.dumps(request.tool_call["args"])
    tool_call_id = request.runtime.tool_call_id
    # 1. 判断同样的函数和参数是否调用过 => 直接使用缓存
    cache_key = (tool_name, tool_args)
    cache = global_cache.get(cache_key)

    if cache:
        # 缓存命中 之前有过调用
        logger.info("{}调用缓存命中，无需调用工具，使用缓存结果：{}", tool_name, cache)
        tool_msg = ToolMessage(
            tool_call_id=tool_call_id,
            content=cache
        )
    else:
        # 缓存没有命中 需要执行工具函数
        tool_msg = execute(request)
        logger.info("将{}的调用结果写入缓存", tool_name)
        global_cache[cache_key] = tool_msg.content

    return tool_msg

# 5. 构建图
builder = StateGraph(state_schema=OverAllState)
builder.add_node("llm_node", llm_node)
builder.add_node("tool_node", ToolNode(tools = tools, wrap_tool_call= wrap_tool_call))


builder.add_edge(START, "llm_node")
builder.add_conditional_edges("llm_node", router, path_map=["tool_node", END])
builder.add_edge("tool_node", "llm_node")

graph = builder.compile()

res = graph.invoke({"messages": [HumanMessage(content="查询一下今天上海的天气")]})

print("//"*50)

for msg in res["messages"]:
    msg.pretty_print()

print("//"*50)

res = graph.invoke({"messages": [HumanMessage(content="查询一下今天上海的天气")]})


for msg in res["messages"]:
    msg.pretty_print()

