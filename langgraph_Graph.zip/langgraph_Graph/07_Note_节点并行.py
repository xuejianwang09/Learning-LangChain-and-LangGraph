from typing import TypedDict, Annotated
from operator import add
from langgraph.graph import StateGraph,START,END
from langgraph.types import Overwrite


# 1.定义状态
class OverAllState(TypedDict):
    logs: Annotated[list[str], add]  # 日志 更新的时候不是覆盖，而是追加
    cur_id: str  # 当前的id，用于记录当前的对话 NOTE1 还是 NOTE2   没有配置reducer，所以不会合并  默认是覆盖

# 2.定义节点
def node_1(state: OverAllState) -> OverAllState:
    for k,v in state.items():
        print(f"TTTT111:  k:{k},v:{v}")
    return {
        "logs": ["note_1运行完成"],
        "cur_id": "note_1",
    }



def node_2(state: OverAllState) -> OverAllState:
    for k,v in state.items():
        print(f"TTTT222:  k:{k},v:{v}")
    return {
        "logs": ["note_2运行完成"],  # 覆盖日志 Overwrite的作用是将日志覆盖为指定的值
        "cur_id": "note_2",
    }

def node_3(state: OverAllState) -> OverAllState:
    for k,v in state.items():
        print(f"TTTT333:  k:{k},v:{v}")
    return {
        "logs": ["note_3运行完成"],  # 覆盖日志 Overwrite的作用是将日志覆盖为指定的值  部分更新是可行的
        # "cur_id": "note_3",  # 因为 node_3 不再写 cur_id，所以并行节点中只有 node_2 写 cur_id，LangGraph 不再发生冲突，因此不报错
    }

def node_4(state: OverAllState) -> OverAllState:
    for k,v in state.items():
        print(f"TTTT444:  k:{k},v:{v}")
    return {
        "logs": ["note_4运行完成"],  # 覆盖日志 Overwrite的作用是将日志覆盖为指定的值
        "cur_id": "note_4",
    }


# 3.定义边
# 3.1 创建图获取建造者
builder = StateGraph(state_schema=OverAllState)
# 3.2 添加节点
builder.add_node(node_1)
builder.add_node(node_2)
builder.add_node(node_3)
builder.add_node(node_4)

# 3.2 定义边
builder.add_edge(START, "node_1")
builder.add_edge("node_1", "node_2")
builder.add_edge("node_1", "node_3")
builder.add_edge("node_2", "node_4")
builder.add_edge("node_3", "node_4")
builder.add_edge("node_4", END)
#4.编译图
graph = builder.compile()

#5.运行图
result = graph.invoke({"cur_id": "start"})
print(result)

# 6.绘制图
raw_mermaid = graph.get_graph().draw_mermaid()
print(raw_mermaid)

# 7.保存图片
png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")
