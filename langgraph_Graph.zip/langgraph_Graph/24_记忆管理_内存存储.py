from langchain_core.messages import HumanMessage
from langchain_core.stores import InMemoryStore
from langgraph import graph
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import StateGraph, START, END
from typing import TypedDict
from langgraph.graph.message import MessagesState
from langchain_openai import ChatOpenAI

model = ChatOpenAI(
    model="qwen3.7-plus",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7,
)

class OverAllState(MessagesState):  # MessagesState内部使用的是add_messages方法，根据id来判断是否覆盖还是追加
    output: str

def llm_node_a(state: OverAllState) -> OverAllState:
    msg = state["messages"]
    res = model.invoke(msg)
    return {
        "messages": [res],
    }


def output_node(state: OverAllState) -> OverAllState:
    return {
        "output": state["messages"][-1].content
    }


# 构建图
builder = StateGraph(OverAllState)
builder.add_node("llm_node_a", llm_node_a)
builder.add_node("output_node",output_node)

builder.add_edge(START, "llm_node_a")
builder.add_edge("llm_node_a", "output_node")
builder.add_edge("output_node", END)

# 配置检查点
checkpointer = InMemorySaver()
graph = builder.compile(checkpointer = checkpointer)

# 配置线程id
config = {
    "configurable":{
        "thread_id":"TEST001"
    }
}
result = graph.invoke({"messages": [HumanMessage("你好，我是JM")]},config = config)
print(result)

result = graph.invoke({"messages": [HumanMessage("你好，我叫什么")]},config = config)
print(result)