from typing import TypedDict, Annotated
from operator import add

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import StateGraph, START, END
from loguru import logger

# 1. 声明状态（关键修改）
class OverAllState(TypedDict):
    final_res: Annotated[list[str], add]

# 2. 声明节点
def node_a(state: OverAllState) -> OverAllState:
    logger.info("node_a被执行")
    return {
        "final_res": ["node_a运行的中间结果"]
    }

def node_b(state: OverAllState) -> OverAllState:
    logger.info("node_b被执行")
    return {
        "final_res": ["node_b运行的中间结果"]
    }

def node_c(state: OverAllState) -> OverAllState:
    logger.info("node_c被执行")
    return {
        "final_res": ["node_c运行的结果"]
    }

def node_d(state: OverAllState) -> OverAllState:
    logger.info("node_d被执行")
    return {
        "final_res": ["node_d运行的结果"]
    }

def node_e(state: OverAllState) -> OverAllState:
    logger.info("node_e被执行")
    return {
        "final_res": ["node_e运行的结果"]
    }

builder = StateGraph(state_schema=OverAllState)

builder.add_node(node_b)
builder.add_node(node_c)
builder.add_node(node_a)
builder.add_node(node_d)
builder.add_node(node_e)

builder.add_edge(START, "node_a")
builder.add_edge("node_a", "node_b")
builder.add_edge("node_b", "node_c")

builder.add_edge(START, "node_d")
builder.add_edge("node_d", "node_e")
builder.add_edge("node_e", "node_c")

builder.add_edge("node_c", END)

# 编译（含静态中断）
checkpointer = InMemorySaver()
graph = builder.compile(
    checkpointer=checkpointer,
    interrupt_before=["node_a", "node_b"],  # 编译的时候添加中断节点  只有在中断节点执行完成后，才会执行后续节点  如果是调用时执行，这里不要写
    interrupt_after=["node_a", "node_b"],  # 编译的时候添加中断节点  只有在中断节点执行完成后，才会执行后续节点  如果是调用时执行，这里不要写
)

config = {
    "configurable": {
        "thread_id": "TEST036"
    }
}

# 执行
"""
静态中断以超步进行，每次超步执行一个节点
a和d并行执行 但d没有中断，也会执行  且不会往下执行
b和c并行执行 但d没有中断，也会执行  且不会往下执行  
最后才执行node_c
"""
first_result = graph.invoke({}, config=config)
print("11111111111111111", first_result)

second_result = graph.invoke(None, config=config)
print("22222222222222222", second_result)

# second_result = graph.invoke(
#     None,
#     config=config,
#     interrupt_before=["node_a", "node_b"],  # 不在编译的时候添加中断节点  那么每次都需要指定中断节点  否则会报错
#     interrupt_after=["node_a", "node_b"],
# )
# print("22222222222222222", second_result)

thrid_result = graph.invoke(None, config=config)
print("33333333333333333", thrid_result)

four_result = graph.invoke(None, config=config)
print("44444444444444444", four_result)

# 绘制 mermaid 图
png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")