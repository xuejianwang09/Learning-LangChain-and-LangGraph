"""
基于 LangChain 的 Agent（使用 AgentExecutor）
"""
import os
from pydantic import BaseModel, Field
from langchain_tavily import TavilySearch
from langchain.tools import tool
from langchain.agents import create_agent
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from dotenv import load_dotenv


load_dotenv()

# ===================== 工具 =====================
web_search = TavilySearch(
    tavily_api_key=os.environ["EA_TAVILY_API_KEY"],
    max_results=4,
    topic="general",
)


@tool
def websearch(question: str) -> str:
    """使用网页搜索获取实时信息，例如天气、新闻、股票、公司地址等"""
    print(f"websearch: {question}")
    return web_search.invoke({"query": question})



model = ChatOpenAI(
    model="qwen-plus",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7
)




class Reference(BaseModel):
    title: str = Field(description="这是寻找到内容的标题")
    url: str = Field(description="这是寻找到内容的网站地址")


class AnswerInfo(BaseModel):
    answer: str = Field(description="这个是最终给用户输出的答案")
    reference: list[Reference] = Field(description="答案的详细的出处")


agent = create_agent(
    model,
    tools=[websearch]
)

# response = agent.invoke(
#     {
#         "messages": [
#             SystemMessage("你是一个活泼的AI小助手"),
#             HumanMessage("你好，我是JM，请帮我查询一下上海小海龟科技有限公司地址是哪里"),
#         ]
#     },
# )
#
# for message in response['messages']:
#     message.pretty_print()