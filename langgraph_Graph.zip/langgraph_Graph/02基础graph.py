from typing import TypedDict, Annotated
from operator import add
from langgraph.graph import StateGraph,START,END

# 1.定义状态
class OverAllState(TypedDict):
    logs: Annotated[list[str], add]  # 日志 更新的时候不是覆盖，而是追加
    cur_id: str  # 当前的id，用于记录当前的对话 NOTE1 还是 NOTE2   没有配置reducer，所以不会合并  默认是覆盖

# 2.定义节点
def node_1(state: OverAllState) -> OverAllState:
    pre_id = state["cur_id"]
    return {
        "logs": ["note_1运行完成"],
        "cur_id": pre_id + ",note_1",
    }

def node_2(state: OverAllState) -> OverAllState:
    pre_id = state["cur_id"]
    return {
        "logs": ["note_2运行完成"],
        "cur_id": pre_id + ",note_2",
    }


# 3.定义边
# 3.1 创建图获取建造者
builder = StateGraph(state_schema=OverAllState)
# 3.2 添加节点
builder.add_node(node_1)
builder.add_node(node_2)
# 3.2 定义边
builder.add_edge(START, "node_1")
builder.add_edge("node_1", "node_2")
builder.add_edge("node_2", END)
#4.编译图
graph = builder.compile()

#5.运行图
result = graph.invoke({"cur_id": "start"})
print(result)

# 6.绘制图
raw_mermaid = graph.get_graph().draw_mermaid()
print(raw_mermaid)

# 7.保存图片
png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")
