
from typing import TypedDict, Literal
from langgraph.graph import StateGraph, START, END, MessagesState
from langgraph.prebuilt import ToolNode
from langchain.tools import tool
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage, ToolMessage
import random
from dataclasses import dataclass


model = ChatOpenAI(
    model="qwen3.7-plus",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7,
)


@tool(parse_docstring=True)
def get_weather(city: str) -> str:
    """
    查询指定城市的当日天气

    Args:
        city: 要查询天气的城市名称，如"北京"、"上海"

    Returns:
        该城市的当日天气描述
    """
    rand_int = random.randint(0, 10)
    if rand_int < 7:
        print("网络波动，请重试")
        raise ConnectionError("网络波动，请重试")
    else:
        return f"{city} 当日的天气为晴朗"


tools = [get_weather]
model_with_tools = model.bind_tools(tools=tools)

#设置最大重试次数为3次 dataclass
@dataclass
class UserContext:
    max_retries: int

# 3. 声明状态 -> 传入的时候 直接写入HumanMessage
class OverAllState(MessagesState):
    output: str


# 4. 定义节点
def llm_node(state: OverAllState) -> OverAllState:
    msg = state["messages"]
    # 调用大模型
    res = model_with_tools.invoke(msg)
    return {
        "messages": [res],
        "output": res.content
    }


def router(state: OverAllState) -> Literal["tool_node", END]:
    if state["messages"][-1].tool_calls:
        return "tool_node"
    return END


#4. 定义工具调用包装器 重试机制
# request: 固定参数 => 可以调用runtime
# execute: 执行 => 执行工具调用
"""
wrap_tool_call 只能写一个
1.当两个工具同时发生错误的时候，此处是串行重试  先重试第一个工具  再重试第二个工具
2.如果两个工具的错误处理不同，可以通过tool_name = request.tool_name ， 在execute_tool_call中添加不同的逻辑  从而实现不同的错误处理机制
"""
def wrap_tool_call(request,execute):
    print("wrap_tool_call 正在执行")
    max_attempts = request.runtime.context.max_retries  # 从 request.runtime.context 中取出最大重试次数  上下文中的最大重试次数
    tool_call_id = request.runtime.tool_call_id
    tool_name = request.tool_name
    tool_msg = ""
    for i in range(max_attempts):
        try:
            tool_msg = execute(request)  # 表示一次工具调用  可以在execute工具调用前和后添加逻辑  从而实现重试机制等其他功能！！！！！
            break
        except ConnectionError as e:
            print(f"第{i+1}次调用失败: {e}")
            continue

    if not tool_msg:
        tool_msg = ToolMessage(
            tool_call_id=tool_call_id,
            content=f"调用次数超过最大重试次数{max_attempts}次，工具调用失败"
        )
    return tool_msg

# 5. 构建图
builder = StateGraph(state_schema=OverAllState, context_schema=UserContext)
builder.add_node("llm_node", llm_node)
builder.add_node("tool_node", ToolNode(tools = tools, wrap_tool_call= wrap_tool_call))



builder.add_edge(START, "llm_node")
builder.add_conditional_edges("llm_node", router, path_map=["tool_node", END])
builder.add_edge("tool_node", "llm_node")

graph = builder.compile()

res = graph.invoke({"messages": [HumanMessage(content="查询一下今天上海的天气")]}, context=UserContext(max_retries=10))

print(res)
print("*"*50)

for msg in res["messages"]:
    msg.pretty_print()