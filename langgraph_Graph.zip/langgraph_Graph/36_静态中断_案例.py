from typing import TypedDict
from operator import add
from typing import TypedDict, Annotated
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import StateGraph,START,END
from langgraph.graph import StateGraph
from loguru import logger

#1. 声明状态
class OverAllState(TypedDict):
    final_res:str

#2. 声明节点
def node_a(state:OverAllState)->OverAllState:
    logger.info("node_a被执行")
    return {
        "final_res":"node_a运行的中间结果"
    }

def node_b(state:OverAllState)->OverAllState:
    logger.info("node_b被执行")
    return {
        "final_res":"node_b运行的中间结果"
    }

def node_c(state:OverAllState)->OverAllState:
    logger.info("node_c被执行")
    return {
        "final_res":"node_c运行的结果"
    }

builder = StateGraph(state_schema=OverAllState)

builder.add_node(node_b)
builder.add_node(node_c)
builder.add_node(node_a)

builder.add_edge(START, "node_a")
builder.add_edge("node_a", "node_b")
builder.add_edge("node_b", "node_c")
builder.add_edge("node_c", END)

# 编译的时候需要添加静态中断
checkpointer = InMemorySaver()
graph = builder.compile(
    checkpointer = checkpointer,
    interrupt_before=["node_a","node_b"],
    interrupt_after=["node_a","node_b"],
)

# 添加config
config = {
        "configurable": {
            "thread_id": "TEST036"
        }
    }

# 执行
first_result = graph.invoke({},config=config)
print("11111111111111111" , first_result)

# 恢复执行 这里要填None
second_result = graph.invoke(None,config=config)
print("22222222222222222" , second_result)

# 恢复执行 这里要填None
thrid_result = graph.invoke(None,config=config)
print("33333333333333333" , thrid_result)

# 恢复执行 这里要填None
four_result = graph.invoke(None,config=config)
print("44444444444444444" , four_result)

# 绘制mermaid图
png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")