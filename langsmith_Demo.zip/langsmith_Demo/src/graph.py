from typing import Literal
from langchain_core.messages import HumanMessage, ToolMessage
from langgraph.graph import StateGraph, START, END, MessagesState
from langgraph.types import Command, interrupt
from src.agent import agent
from langgraph.checkpoint.memory import InMemorySaver


# ===================== State =====================
class OverAllState(MessagesState):
    """
    MessagesState 已经包含：
        messages: Annotated[list, add_messages]

    这里只追加你自己的业务字段
    """
    input_query: str
    output_result: str
    is_approved: str


# ===================== 节点 =====================
def approve_node(
    state: OverAllState,
) -> Command[Literal["llm_node", "default_node"]]:
    """
    HITL 审批节点
    当前 approval 写死为 yes，后续可打开 interrupt 做真正的人工中断
    """
    approval = interrupt("是否同意调用 LLM？")
    # approval = "yes"

    if approval == "yes":
        return Command(
            goto="llm_node",
            update={"is_approved": approval},
        )
    else:
        return Command(
            goto="default_node",
            update={"is_approved": approval},
        )


def llm_node(state: OverAllState) -> dict:
    input_query = state["input_query"]
    response = agent.invoke({"messages": [HumanMessage(input_query)]})
    # 获取最后一个消息（最新回复）
    latest_message = response["messages"][-1]
    return {
        "messages": [
                    HumanMessage(input_query),
                    latest_message,
                    ],  # 把用户的提问与AI的回答都记录到messages
        "output_result": latest_message.content,
    }


def default_node(state: OverAllState) -> dict:
    return {
        "messages": [
            HumanMessage(content="请求被拒绝了")
        ],
        "output_result": "请求被拒绝了",
    }


def output_node(state: OverAllState) -> dict:
    """
    最终输出节点（可做日志、格式化等）
    """
    return {
        "output_result": state["output_result"],
    }


# ===================== 构图 =====================
builder = StateGraph(OverAllState)

builder.add_node("approve_node", approve_node)
builder.add_node("llm_node", llm_node)
builder.add_node("default_node", default_node)
builder.add_node("output_node", output_node)

builder.add_edge(START, "approve_node")
builder.add_edge("llm_node", "output_node")
builder.add_edge("default_node", "output_node")
builder.add_edge("output_node", END)


graph = builder.compile()
# 为什么这里使用langsmith dev运行，中断不需要添加checkpoint
# langgraph dev 之所以能“恢复”这个中断，是因为它背后已经自动帮你用了 checkpoint
# 但如果你自己写脚本 graph.invoke(...)，不传 checkpointer 是会报错的
