from typing import TypedDict

from anyio.lowlevel import checkpoint
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import StateGraph, START, END


# ==================== 子图 ====================
class SubgraphState(TypedDict):
    raw_text: str
    stripped_text: str
    punctuated: str


def subgraph_strip_node(state: SubgraphState) -> SubgraphState:
    print("正在调用子图节点 subgraph_strip_node")
    return {
        "stripped_text": state["raw_text"].strip()
    }


def subgraph_punctuate_node(state: SubgraphState) -> SubgraphState:
    print("正在调用子图节点 subgraph_punctuate_node")
    return {
        "punctuated": state["stripped_text"] + "."
    }


subgraph_builder = StateGraph(SubgraphState)
subgraph_builder.add_node("strip", subgraph_strip_node)
subgraph_builder.add_node("punctuate", subgraph_punctuate_node)
subgraph_builder.add_edge(START, "strip")
subgraph_builder.add_edge("strip", "punctuate")
subgraph_builder.add_edge("punctuate", END)

subgraph_graph = subgraph_builder.compile()


# ==================== 父图 ====================
class ParentState(TypedDict):
    input_text: str
    raw_text: str
    stripped_text: str
    punctuated: str
    output_text: str


def prepare_subgraph_input(state: ParentState) -> ParentState:
    print("正在调用父图节点 prepare_subgraph_input")
    return {
        "raw_text": state["input_text"]
    }


def finalize_output(state: ParentState) -> ParentState:
    print("正在调用父图节点 finalize_output")
    return {
        "output_text": state["punctuated"]
    }


parent_builder = StateGraph(ParentState)

# 子图作为节点直接挂进来
parent_builder.add_node("prepare_input", prepare_subgraph_input)
parent_builder.add_node("text_processor", subgraph_graph)  # ✅ 关键改动！！！！！！！！！！！！！！！
parent_builder.add_node("finalize_output", finalize_output)

parent_builder.add_edge(START, "prepare_input")
parent_builder.add_edge("prepare_input", "text_processor")
parent_builder.add_edge("text_processor", "finalize_output")
parent_builder.add_edge("finalize_output", END)

"""
✅️ 添加检查点查看子图检查点
"""
checkpointer = InMemorySaver()
parent_graph = parent_builder.compile(checkpointer=checkpointer)

config = {
    "configurable": {
        "thread_id": "TEST036"
    }
}

# ==================== 运行 ====================
res = parent_graph.invoke({
    "input_text": " 你好, 我是JM啊啊啊啊啊啊啊  "
}, config=config)
print(res)



# 检查点的查看
history = list(parent_graph.get_state_history(config = config))
print(history)
print("000*"*100)
# ✅️ 获取到即将调用子图检查点的config
parent_config = history[2].config
print(parent_config)
# ✅️ 展开子图的检查点  但是❌️并没有展示所有的子图检查点  只是显示子图的调用结果
print("111*"*100)
subgraph_history = parent_graph.get_state(config = parent_config,subgraphs=True)  # 展开子图的检查点, 查看子图的状态历史 subgraphs=True
print(subgraph_history)


# ✅️ 获取到即将调用子图检查点的tasks的state   获取到子图的checkpoint_ns，就可以查看完整子图的检查点
print("222*"*100)
sub_config = history[2].tasks[0].state
print(sub_config) #   state=   {'configurable': {'thread_id': 'TEST036', 'checkpoint_ns': 'text_processor:b9535e69-cb16-df19-6cba-fbc16c13ad2e'}}
# ✅️ 最终使用父图查看sub_config 子图的所有检查点
print("333*"*100)
sub_history =list(parent_graph.get_state_history(config = sub_config))
print(sub_history)

# ❗️ 总结 在父图的检查点钟是使用checkpoint_ns来区分不同的子图检查点的



# png_bytes = parent_graph.get_graph(xray=True).draw_mermaid_png()   # 添加xray=True可以查看子图的节点！！！！！！！！！！！！！！
# with open("mermaid_graph.png", "wb") as f:
#     f.write(png_bytes)
# print("图片已保存为 mermaid_graph.png")