from langgraph.graph import StateGraph, START, END
from typing import TypedDict
# 输入状态
class InputState(TypedDict):
    username: str
# 输出状态
class OutputState(TypedDict):
    graph_output: str
# 全局状态
class OverAllState(TypedDict):
    username: str
    graph_output: str
    logs: list[str]
    nickname: str
# 私有状态
class PrivateState(TypedDict):
    greeting: str


def node_1(state: InputState) -> OverAllState:
    # 从输入状态中获取用户名
    username = state["username"]
    return {
        "nickname": "dear" + username,
    }

def node_2(state: OverAllState) -> PrivateState:
    """读取全局状态，生成私有数据"""
    print(f"TTTT222: 读取 nickname={state['nickname']}")
    return {
        "greeting": f"Hello, {state['nickname']}",
        "nickname": state["nickname"]  # 保持字段一致（虽然 PrivateState 不一定需要回传）
    }

def node_3(state: PrivateState) -> OutputState:
    """读取私有数据，生成最终输出"""
    print(f"TTTT333: 读取 greeting={state['greeting']}")
    return {
        "graph_output": f"{state['greeting']}，欢迎来到 LangGraph！"
    }

# 3. 构建图
builder = StateGraph(
    state_schema=OverAllState,
    input_schema=InputState,
    output_schema=OutputState
)

builder.add_node("node_1", node_1)
builder.add_node("node_2", node_2)
builder.add_node("node_3", node_3)

builder.add_edge(START, "node_1")
builder.add_edge("node_1", "node_2")
builder.add_edge("node_2", "node_3")
builder.add_edge("node_3", END)

# 4. 编译并运行
graph = builder.compile()

result = graph.invoke({"username": "JM"})
print("最终返回结果:", result)