from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, START, END
from typing import TypedDict, Literal
from langgraph.graph.message import MessagesState
from langchain_openai import ChatOpenAI

model = ChatOpenAI(
    model="qwen3.7-plus",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7,
)

class OverAllState(MessagesState):  # MessagesState内部使用的是add_messages方法，根据id来判断是否覆盖还是追加
    topic: str
    poem: str
    joke: str
    content_type: str

def llm_node_a(state: OverAllState) -> OverAllState:
    res = model.invoke(f"写一首关于{state['topic']}的诗")
    return {
        "poem": res.content,
    }

def llm_node_b(state: OverAllState) -> OverAllState:
    res = model.invoke(f"写一个关于{state['topic']}的笑话")
    return {
        "joke": res.content,
    }

def route_node(state: OverAllState) -> Literal["poem", "joke"]:
    if "笑话" in state["content_type"]:
        return "joke"
    else:
        return "poem"


# 4. 构建图
builder = StateGraph(OverAllState)
builder.add_node("llm_node_a", llm_node_a)
builder.add_node("llm_node_b", llm_node_b)

builder.add_conditional_edges(START, route_node,path_map={"poem": "llm_node_a", "joke": "llm_node_b"})
builder.add_edge("llm_node_a", END)
builder.add_edge("llm_node_b", END)


# 5. 编译运行
graph = builder.compile()
result = graph.invoke({"topic": "狗狗", "content_type": "诗"})
print(result)

# 7.保存图片
png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")