from langgraph.graph import StateGraph, START, END
from langgraph.types import CachePolicy
from loguru import logger
from typing import TypedDict, Annotated
from langgraph.cache.memory import InMemoryCache
import operator
import time


# 1. 声明状态
class OverAllState(TypedDict):
    user: str
    invoke_counts: Annotated[int, operator.add]


# 2. 声明节点
def node_a(state: OverAllState) -> OverAllState:
    logger.info("node_a被调用 user:{}", state["user"])
    time.sleep(3)
    logger.info("node_a耗时操作执行完成")
    return {"invoke_counts": 1}


def end_node(state: OverAllState) -> OverAllState:
    logger.info("流程结束，总调用次数: {}", state["invoke_counts"])
    return state


# 3. 构建图
builder = StateGraph(state_schema=OverAllState)

builder.add_node("node_a", node_a,cache_policy=CachePolicy(
    ttl=10,  # 缓存过期时间，单位秒
    # key_func=lambda state: state["user"],
))
builder.add_node("end_node", end_node)

builder.add_edge(START, "node_a")
builder.add_edge("node_a", "end_node")
builder.add_edge("end_node", END)

graph = builder.compile(cache=InMemoryCache())  # 缓存在内存中

# 7.保存图片
png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")


res = graph.invoke({"user": "TestUser", "invoke_counts": 0})
print("最终打印调用次数:", res["invoke_counts"])
"""
为什么打印的是2  invoke_counts 在一次 invoke() 中被 operator.add 累加了两次：一次是正常执行，一次是 cache 写入时的隐式 merge。
"""
res = graph.invoke({"user": "TestUser", "invoke_counts": 0})  # 再次调用，缓存未过期，直接返回缓存结果 不调用node_a
print("最终打印调用次数:", res["invoke_counts"])

# 等待10秒，缓存过期
time.sleep(10)

res = graph.invoke({"user": "TestUser", "invoke_counts": 0})  # 再次调用，缓存过期，调用node_a
print("最终打印调用次数:", res["invoke_counts"])