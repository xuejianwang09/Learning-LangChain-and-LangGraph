"""
HITL  表示Human in the loop，即人机交互
"""
from time import sleep
from typing import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.types import Command, interrupt
from langgraph.checkpoint.memory import InMemorySaver


class OverAllState(TypedDict):
    username: str
    age: int

def node_a(state: OverAllState) -> OverAllState:
    print("我是node_a节点......................................")
    username = interrupt("请输入您的姓名啊")  # 中断图，等待用户输入姓名
    return {
        "username": username
    }

def node_b(state: OverAllState) -> OverAllState:
    print("我是node_b节点......................................")
    sleep(2)
    age = interrupt("请输入您的年龄啊")  # 中断图，等待用户输入年龄
    return {
        "age": int(age)
    }


builder = StateGraph(OverAllState)
builder.add_node("node_a", node_a)
builder.add_node("node_b", node_b)
builder.add_edge(START, "node_a")
builder.add_edge(START, "node_b")
builder.add_edge("node_a", END)
builder.add_edge("node_b", END)

# 想要中断，必须配置checkpoint
checkpointer = InMemorySaver()
graph = builder.compile(checkpointer = checkpointer)

config = {
    "configurable": {
        "thread_id": "TEST036"
    }
}

# 执行中断
res = graph.invoke({},config = config)
print(res)

# 处理中断

"""
在checkpoint中
task会记录中断的状态，包括中断的value  id  state result
interrupts会记录两个中断 value  id
"""

resume_dict = {}
for one_interrupt in res['__interrupt__']:
    print("处理中断：" + one_interrupt.value)
    user_input = input(one_interrupt.value)
    if "年龄" in one_interrupt.value:
        resume_dict[one_interrupt.id] = int(user_input)
    else:
        resume_dict[one_interrupt.id] = user_input
print(
   "处理后的中断字典："  + str(resume_dict)  # 处理后的中断字典：{'bea87ed35c806171685c0b6f3385cf84': 'JM', 'e6b99b6f2a2ee4e9e29fc44085876162': 18}
)

#恢复图的中断  多个需要做成字典
resum = graph.invoke(Command(resume=resume_dict),config = config)
print(resum)

















png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")