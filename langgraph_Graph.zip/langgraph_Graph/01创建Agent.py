from langchain.agents import create_agent
from langchain.chat_models import init_chat_model
from langchain.tools import tool
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from langgraph.prebuilt import ToolNode
from langgraph.graph import StateGraph,START,END

model = init_chat_model(
    model="qwen3.5-omni-plus-2026-03-15",
    model_provider="openai",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
)


@tool
def websearch(flag: bool):
    """通路进行网页搜索"""
    if flag:
        raise ValueError("ssssss")
    return "晴天"


def handle_error() ->bool:
    print("error")
    return True


tool_node = ToolNode(
    [websearch],
    handle_tool_errors=True,
)

agent = create_agent(
    model=model,
    tools=[],
    system_prompt="你是我的助手"
)

for chunk, _metadata in agent.stream(
        {"messages": [HumanMessage("我的名字是JM")]},
        stream_mode="messages",
):
    if chunk.content:
        print(chunk.content, end="", flush=True)
