"""
HITL  表示Human in the loop，即人机交互
"""
from time import sleep
from typing import TypedDict, Literal

from langchain_core.messages import HumanMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START, END
from langgraph.types import Command, interrupt
from langgraph.checkpoint.memory import InMemorySaver

model = ChatOpenAI(
    model="qwen3.7-plus",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7,
)

class OverAllState(TypedDict):
    topic: str
    poem: str
    is_approved: bool

# 声明节点
def approve_node(state: OverAllState) -> Command[Literal["llm_node", "default_node"]]:
    approval = interrupt("是否同意调用LLM？")
    return Command(
        goto="llm_node" if approval else "default_node",
        update={"is_approved": approval}
    )

def llm_node(state: OverAllState) -> OverAllState:
    topic = state["topic"]
    res = model.invoke([HumanMessage(content=f"请帮我写一首关于{topic}的诗")])
    return {
        "poem": res.content
    }

def default_node(state: OverAllState) -> OverAllState:
    return {
        "poem": "请求被拒绝了"
    }


builder = StateGraph(OverAllState)
builder.add_node("approve_node", approve_node)
builder.add_node("llm_node", llm_node)
builder.add_node("default_node", default_node)

builder.add_edge(START, "approve_node")
builder.add_edge("llm_node", END)
builder.add_edge("default_node", END)

# 想要中断，必须配置checkpoint
checkpointer = InMemorySaver()
graph = builder.compile(checkpointer = checkpointer)

config = {
    "configurable": {
        "thread_id": "TEST036"
    }
}

# 执行中断
res = graph.invoke({"topic": "动物"},config = config)
print(res)

# 处理中断
resume_dict = {}
for i in res['__interrupt__']:
    user_input = input(i.value + "yes/no")
    if "yes" in user_input:
        resume_dict[i.id] = True
    else:
        resume_dict[i.id] = False

#恢复图的中断  多个需要做成字典
resum = graph.invoke(Command(resume=resume_dict),config = config)
print(resum)

















png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")