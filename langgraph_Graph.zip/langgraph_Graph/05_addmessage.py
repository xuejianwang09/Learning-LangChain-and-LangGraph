from langchain.messages import SystemMessage, HumanMessage, AIMessage
from langgraph.graph import add_messages
# 如果消息有相同的 id，右边（新消息）会覆盖左边（旧消息）；没有相同 id 的会追加
left = [
    SystemMessage(content="你是一个专业的翻译", id='1'),
    HumanMessage(content="你好", id='2'),
    AIMessage(content="你好，我是专业的翻译", id='3'),
]

right = [
    HumanMessage(content="我是老王,你是小王", id='2'),
    AIMessage(content="好的我记住了", id='3'),
    HumanMessage(content="你是谁?", id='4'),
    AIMessage(content="我是小王", id='5'),
]

merged = add_messages(left, right)
print(merged)
