from uuid import NAMESPACE_DNS

from langgraph.store.postgres import PostgresStore
from typing import Final, Tuple, Literal

from setuptools import namespaces

DB_URL = "postgresql://my_langgraph_user:123456@localhost:5432/langgraph_db?sslmode=disable"
with PostgresStore.from_conn_string(DB_URL) as store:  # 第一次使用 需要setup数据库
     store.setup()
     # 构建永久记忆数据
     USER_NS:Final[Tuple[str]] = ("users",)  # 构建用户命名空间，用于存储用户相关的永久记忆
     PREFERENCES_KEY:Final[str] = "preferences"  # 构建用户偏好键，用于存储用户偏好
     namespace1 = (*USER_NS, "JM")
     namespace2 = (*USER_NS, "LG")
     namespace3 = (*USER_NS, "AM")

     value1 = {
          "sports": "带娃",
          "food": "红烧肉，鱼香肉丝",
          "music": "我爱我的祖国",
          "game": "LOL",
     }

     value2 = {
          "sports": "骑车",
          "food": "披萨，汉堡，可乐",
          "music": "青花瓷",
          "game": "崩坏，原神",
     }

     value3 = {
          "sports": "看电影",
          "food": "饭菜",
          "music": "JJB",
          "game": "AI短剧",
     }

     #写入永久记忆数据
     store.put(namespace1, PREFERENCES_KEY, value1)
     store.put(namespace2, PREFERENCES_KEY, value2)
     store.put(namespace3, PREFERENCES_KEY, value3)

     for item in store.search(USER_NS):
          print(item)
