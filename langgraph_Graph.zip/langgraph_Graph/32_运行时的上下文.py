from difflib import context_diff
from dataclasses import dataclass

from loguru import logger
from langchain_core import messages
from langchain_core.messages import ToolMessage
from langgraph import graph
from langgraph.store.postgres import PostgresStore
from typing import Final, Tuple, Literal
from langchain.messages import SystemMessage, HumanMessage, AIMessage
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.graph import StateGraph, START, END, MessagesState
from langchain_openai import ChatOpenAI
from langgraph.runtime import Runtime


model = ChatOpenAI(
    model="qwen3-max-preview",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7,
    extra_body={
        "enable_thinking": False,  # 硬关思考链（Qwen 混合模型标准开关）
        # "reasoning": {"effort": "none"},  # 新接口也可用这个，二选一
    },
)

# 1. 定义运行时上下文类型
@dataclass
class UserContext:
    username: str
    membership_level: str  # "普通用户" / "VIP"

# 2. 定义图状态
class OverAllState(MessagesState):
    user_input: str
    output: str

# 3. 定义节点：通过 runtime.context 访问运行时上下文
def llm_node(state: OverAllState, runtime: Runtime[UserContext]) -> OverAllState:
    runtime_context = runtime.context

    if runtime_context:
        username = runtime_context.username
        level = runtime_context.membership_level
        logger.info(f"当前用户：{username}，会员等级：{level}")

        if level == "VIP":
            system_prompt = f"你是高级客服助理，当前VIP用户是{username}，请使用尊称'您'，语气热情周到，回复末尾加上'💎VIP专属服务'。"
        else:
            system_prompt = f"你是普通客服助理，当前用户是{username}，请友好简洁地回复。"
    else:
        logger.warning("运行时上下文为空，使用默认风格")
        system_prompt = "你是客服助理，请友好简洁地回复。"

    user_input = state["user_input"]
    messages = state.get("messages", [])
    res = model.invoke([SystemMessage(content=system_prompt)] + messages + [HumanMessage(content=user_input)])
    return {
        "messages": messages,
        "output": res.content
    }

builder = StateGraph(state_schema=OverAllState,context_schema=UserContext)

builder.add_node(llm_node)
builder.add_edge(START, "llm_node")
builder.add_edge("llm_node", END)

graph = builder.compile()

# res = graph.invoke(
#     {"user_input": "你好,帮我查一下最近的优惠活动"},
#     context=UserContext(username="张三", membership_level="VIP")
# )
# print(res)


res = graph.invoke(
    {"user_input": "你好,帮我查一下最近的优惠活动"},
    context=UserContext(username="张三", membership_level="普通用户")
)
print(res)