"""
通过动态扇入实现MapReduce任务   统计每个单词出现的次数
"""

from typing import TypedDict, Literal, Annotated, Sequence
from operator import add

from langgraph.graph import StateGraph, START, END
from langgraph.types import Send, Command
from collections.abc import Iterable


class OverAllState(TypedDict):
    input_values: list[str]  # 输入的字符串列表
    entryList:Annotated[list[tuple[str, int]],add]  # 每个单词出现的次数  (单词, 出现的次数)  可追加
    wordCount:dict[str, int]  # 最终的结果

class MapInputState(TypedDict):  # 这里是私有状态  只在mapper_node中使用  不会被其他节点使用
    input_value: str


# 创建路由  分发任务给mapper_node
def router(state:OverAllState) -> Sequence[Send]:  # 静态并行路由
    # 拿到input_value
    input_values = state["input_values"]
    task = []
    for input_value in input_values:
        task.append(Send(
            "mapper_node",
            {
                "input_value": input_value,
        }
        ))
    return task

#定义mapper_node  对每个单词进行拆分  并统计每个单词出现的次数
def mapper_node(state: MapInputState) -> OverAllState:
    input_value = state["input_value"]
    words = input_value.split(" ")
    emptyList = []
    for word in words:
        emptyList.append((word, 1))
    print("*"*20 +"mapper_node"+ str(emptyList))
    return {
        "entryList": emptyList  # 这里是mapper_node的结果  每个单词出现的次数  (单词, 出现的次数)  可追加
    }

# 聚合所有的mapper_node的结果  并统计每个单词出现的次数
def reducer_node(state: OverAllState) -> OverAllState:
    entryList = state["entryList"]
    wordCount = {}
    for word, count in entryList:
        if word in wordCount:
            wordCount[word] += count
        else:
            wordCount[word] = count
    print("*"*20 +"reducer_node"+ str(wordCount))
    return {
        "wordCount": wordCount
    }


# 4. 构建图
builder = StateGraph(state_schema=OverAllState)


builder.add_node("mapper_node", mapper_node)
builder.add_node("reducer_node", reducer_node)


builder.add_conditional_edges(START, router, path_map=["mapper_node"])
builder.add_edge("mapper_node", "reducer_node")
builder.add_edge("reducer_node", END)

# 5. 编译运行
graph = builder.compile()
result = graph.invoke({
    "input_values": ["hello world", "hello langgraph", "hello world langgraph", "hello JM langgraph"]
})
print(result)



# 7.保存图片
png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")
