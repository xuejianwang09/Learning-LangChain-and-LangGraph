"""
HITL  表示Human in the loop，即人机交互
"""

from typing import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.types import Command, interrupt
from langgraph.checkpoint.memory import InMemorySaver


class OverAllState(TypedDict):
    username: str
    age: str
    gender: str


def node_a(state: OverAllState) -> OverAllState:
    print("我是node_a节点......................................")
    username = interrupt("请输入您的姓名***")  # 中断图，等待用户输入姓名
    age = interrupt("请输入您的年龄***")  # 中断图，等待用户输入年龄
    gender = interrupt("请输入您的性别***")  # 中断图，等待用户输入性别
    return {
        "username": username,
        "age": age,
        "gender": gender
    }

builder = StateGraph(OverAllState)
builder.add_node(node_a)
builder.add_edge(START, "node_a")
builder.add_edge("node_a", END)

# 想要中断，必须配置checkpoint
checkpointer = InMemorySaver()
graph = builder.compile(checkpointer = checkpointer)

config = {
    "configurable": {
        "thread_id": "TEST032"
    }
}

# 执行中断
res = graph.invoke({},config = config)
print(res)
print("------------------------------------------------")
# 处理中断  LangGraph 的 resume 不是“按名字恢复”，而是“按中断顺序，从 checkpoint 中恢复”。
"""
在checkpoint中三次恢复中断状态 ，每次的checkpoint 只会记录一条中断的状态。
但是每次的checkpoint的ID和中断的ID都是一样的
每次的value不同

但是每次输入的内容，在checkpoint中不可见  但是肯定的是存储的
"""
user_name = input("请输入您的用户名：")
age_interrupted_res = graph.invoke(Command(resume=user_name), config=config)
print('=' * 30, '-> age_interrupted_res <-', '=' * 30)
print(age_interrupted_res)

user_age = input("请输入您的年龄：")
gender_interrupted_res = graph.invoke(Command(resume=int(user_age)), config=config)
print('=' * 30, '-> gender_interrupted_res <-', '=' * 30)
print(gender_interrupted_res)

user_gender = input("请输入您的性别：(male/female)：")
resumed_res = graph.invoke(Command(resume=user_gender), config=config)
print('=' * 30, '-> resumed_res <-', '=' * 30)
print(resumed_res)






png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")