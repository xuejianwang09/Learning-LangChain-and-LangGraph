from typing import TypedDict
from langchain_core.runnables import RunnableConfig
from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, START, END
from langgraph.types import Send, Command
from langgraph.graph.message import MessagesState
from langchain_openai import ChatOpenAI
from typing import TypedDict, Literal, Sequence

class Empty_state(TypedDict):
    pass

def note_a(state: Empty_state,config: RunnableConfig) -> Empty_state:
    cur_step = config["metadata"]["langgraph_step"]
    print(f"当前步骤：{cur_step}")
    return state

def note_b(state: Empty_state,config: RunnableConfig) -> Empty_state:
    cur_step = config["metadata"]["langgraph_step"]
    print(f"当前步骤：{cur_step}")
    return state

def note_c(state: Empty_state,config: RunnableConfig) -> Empty_state:
    cur_step = config["metadata"]["langgraph_step"]
    print(f"当前步骤：{cur_step}")
    return state

def note_d(state: Empty_state,config: RunnableConfig) -> Empty_state:
    cur_step = config["metadata"]["langgraph_step"]
    print(f"当前步骤：{cur_step}")
    return state

def note_e(state: Empty_state,config: RunnableConfig) -> Empty_state:
    cur_step = config["metadata"]["langgraph_step"]
    print(f"当前步骤：{cur_step}")
    return state



# 4. 构建图
builder = StateGraph(state_schema=Empty_state)

builder.add_node("note_a_node", note_a)
builder.add_node("note_b_node", note_b)
builder.add_node("note_c_node", note_c)
builder.add_node("note_d_node", note_d)
builder.add_node("note_e_node", note_e)


builder.add_edge(START, "note_a_node")
builder.add_edge("note_a_node", "note_b_node")
builder.add_edge("note_a_node", "note_c_node")
builder.add_edge("note_b_node", "note_d_node")
# builder.add_edge("note_c_node", "note_e_node")  # 或 c执行完就可以执行e    e执行了两次
# builder.add_edge("note_d_node", "note_e_node")
builder.add_edge(["note_c_node", "note_d_node"], "note_e_node")  # 与 必须cd都执行完才能执行e
builder.add_edge("note_e_node", END)



# 5. 编译运行
graph = builder.compile()
result = graph.invoke({})




# 7.保存图片
png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")