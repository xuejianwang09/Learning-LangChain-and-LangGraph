from idlelib import history
from pydoc_data import topics

from langchain_core.messages import HumanMessage
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import MessagesState
from langchain_openai import ChatOpenAI

model = ChatOpenAI(
    model="qwen3.7-plus",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7,
    extra_body={
        "enable_thinking": False,   # 硬关思考链（Qwen 混合模型标准开关）
        # "reasoning": {"effort": "none"},  # 新接口也可用这个，二选一
    },
)

class OverAllState(MessagesState):  # MessagesState内部使用的是add_messages方法，根据id来判断是否覆盖还是追加
    topic: str
    poem: str
    joke: str
    final_output: str

class InputState(MessagesState):
    topic: str

class OutputState(MessagesState):
    final_output: str

topics = ["布偶猫","狸花猫", "金渐层猫","银渐层"]
topics_index = 2;  # 若当前是恢复继续运行，那么不管怎么改，都是从刚刚失败的状态开始恢复  因此还是第一次出错的狸花猫

# 切换主题
def switch_topic(state: InputState) -> OverAllState:
    global topics_index
    topics_index += 1
    if topics_index >= len(topics):
        topics_index = 0
    return {
        "topic": f"{state['topic']} : {topics[topics_index]}"
    }

def node_poem(state: OverAllState) -> OverAllState:
    print("正在执行node_poem！！！！！！！！！！！！")
    topic: str = state["topic"]
    res = model.invoke([HumanMessage(f"写一首关于{topic}的诗")])
    return {
        "poem": res,
    }

import time
def node_joke(state: OverAllState) -> OverAllState:
    print("正在执行node_joke！！！！！！！！！！！！")
    topic: str = state["topic"]
    # time.sleep(5)
    # raise Exception("人为异常  node_joke 失败")
    res = model.invoke([HumanMessage(f"写一个关于{topic}的笑话")])
    return {
        "joke": res,
    }


def node_output(state: OverAllState) -> OutputState:
    print("正在执行node_output！！！！！！！！！！！！")
    topic = state["topic"]
    poem = state["poem"]
    joke = state["joke"]
    final_output = f"{topic}的诗是：{poem}\n{topic}的笑话是：{joke}\n"
    return {
        "final_output": final_output,
    }


# 构建图
builder = StateGraph(state_schema=OverAllState,input_schema=InputState,output_schema=OutputState)

builder.add_node("output_node",node_output)
builder.add_node("node_poem",node_poem)
builder.add_node("node_joke",node_joke)
builder.add_node("switch_topic",switch_topic)

builder.add_edge(START, "switch_topic")
builder.add_edge("switch_topic", "node_poem")
builder.add_edge("switch_topic", "node_joke")
builder.add_edge("node_poem", "output_node")
builder.add_edge("node_joke", "output_node")
builder.add_edge("output_node", END)

# 配置检查点
DB_URL = "postgresql://my_langgraph_user:123456@localhost:5432/langgraph_db?sslmode=disable"

with PostgresSaver.from_conn_string(DB_URL) as checkpointer:  # 第一次使用 需要setup数据库
    checkpointer.setup()
    graph = builder.compile(checkpointer = checkpointer)

    # 配置线程id
    config = {
        "configurable":{
            "thread_id":"TEST005"
        }
    }

    """
    注意这里是第一次运行，发生了错误 node_joke人为异常，导致了检查点的失败
    """
    # result = graph.invoke({"topic": "猫"},config = config)
    # print(result)
    """
    第二次运行，我们修复了bug，尝试恢复检查点的失败  invoke(None) 表示从检查点恢复，恢复到最新状态
    """
    result = graph.invoke(None,config = config)
    print(result)

    png_bytes = graph.get_graph().draw_mermaid_png()
    with open("mermaid_graph.png", "wb") as f:
        f.write(png_bytes)
    print("图片已保存为 mermaid_graph.png")

    print("-----------------")

    # 查看历史检查点 get_state_history
    history_checkpoints2 = list(graph.get_state_history(config))
    print(history_checkpoints2)
