"""
中间件：： 当识别到需要“生成报告”，就切换提示词

正常使用主提示词与客户聊天，当用户需要“生成报告”的时候，主提示词会引导调用fill_context_for_report工具，当调用工具的时候，中间件捕获特定工具使用，标记Flag
为什么可修订report这个Flag？（request.runtime.context 是一个「可变共享字典」完全可以修改它），而且runtime会贯穿整个Agent从模型到Agent调用的全流程？
工具调用结束后，加载提示词时会根据Flag动态切换提示词
"""

from typing import Callable, Optional
from langchain.agents.middleware import wrap_tool_call, before_model, dynamic_prompt, ModelRequest
from langchain.tools.tool_node import ToolCallRequest
from langchain_core.messages import ToolMessage
from langgraph.runtime import Runtime
from langgraph.types import Command, StateSnapshot
from utils.logger_handler import logger
from utils.prompt_loader import load_system_prompts, load_report_prompts


@wrap_tool_call  # 工具执行的监控
def monitor_tool(
        # 请求的数据封装
        request: ToolCallRequest,
        # 执行的函数本身
        handler: Callable[[ToolCallRequest], ToolMessage | Command],  # 工具执行的监控
) -> ToolMessage | Command:
    logger.info(f"[tool monitor]执行工具: {request.tool_call['name']}")
    logger.info(f"[tool monitor]传入参数: {request.tool_call['args']}")

    try:
        result = handler(request)
        logger.info(f"[tool monitor]工具{request.tool_call['name']}调用成功")

        if request.tool_call['name'] == "fill_context_for_report":  # 发现fill_context_for_report被调用了  标记report为true
            request.runtime.context['report'] = True  # request.runtime.context 是一个「可变共享字典」完全可以修改它

        return result
    except Exception as e:
        logger.error(f"工具{request.tool_call['name']}调用失败, 原因: {str(e)}")
        raise


@before_model  # 注意：这通常是 LangGraph 内部的钩子，实际使用需确保框架支持
def log_before_model(
        state: StateSnapshot,  # 对应 AgentState
        runtime: Runtime,  # 运行时上下文
) -> None:
    """
    在模型调用前记录日志。
    """
    # 记录即将调用模型的消息数量
    logger.info(f"[log_before_model] 即将调用模型, 带有 {len(state['messages'])} 条消息。")

    # 记录最后一条消息的类型和内容摘要 (用于调试)
    if state['messages']:
        last_msg = state['messages'][-1]
        logger.debug(
            f"[log_before_model] 最后一条消息类型: {type(last_msg).__name__}, "
            f"内容预览: {str(last_msg.content)[:500]}..."  # 只取前100字符防止日志过大
        )

    return None


@dynamic_prompt  # 每次调模型前，按运行时上下文动态生成 System Prompt，替代写死的静态 system_prompt
def report_prompt_switch(  # 动态切换提示词
        request: ModelRequest,  # 每一次在生成提示词之前，调用此函数
) -> Optional[str]:  # 动态切换提示词
    """
        动态判断当前是否为报告生成场景，并切换对应的 System Prompt。
        """
    # 从运行时上下文中获取 "report" 标志位，默认为 False
    is_report = request.runtime.context.get("report", False)

    if is_report:
        # 是报告生成场景，返回报告生成的提示词内容
        logger.info("[dynamic_prompt] 提示词切换到【报告生成】模式")
        return load_report_prompts()
    else:
        # 默认场景，返回普通系统提示词
        logger.info("[dynamic_prompt] 提示词切换到【普通对话】模式")
        return load_system_prompts()
