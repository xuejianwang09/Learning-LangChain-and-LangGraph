from typing import TypedDict
from langgraph.graph import StateGraph, START, END


class OverallState(TypedDict):
    initial_state: str
    node_a_output: str
    node_b_output: str


def node_a(state: OverallState) -> OverallState:
    return {
        "node_a_output": "节点A的输出"
    }


def node_b(state: OverallState) -> OverallState:
    return {
        "node_b_output": "节点B的输出"
    }


builder = StateGraph(state_schema=OverallState)
builder.add_node("node_a", node_a)
builder.add_node("node_b", node_b)
builder.add_edge(START, "node_a")
builder.add_edge("node_a", "node_b")
builder.add_edge("node_b", END)

graph = builder.compile()
for chunk in graph.stream(
    {"initial_state": "初始状态"},
    # stream_mode=["values"], # 流式输出节点的输出值
    stream_mode=["updates"], # 流式输出节点的更新状态
):
    print(chunk)
