from distutils import command
from json import tool
from typing import TypedDict, Literal

from langchain_core.messages import HumanMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START, END, MessagesState
from langgraph.prebuilt import ToolRuntime, ToolNode
from langgraph.types import Command, interrupt
from pydantic import BaseModel, Field
from langchain_tavily import TavilySearch
from langchain.tools import tool
from langchain.agents import create_agent
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage, ToolMessage
from dotenv import load_dotenv

model = ChatOpenAI(
    model="qwen3.7-plus",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7,
)


@tool(parse_docstring=True)
def get_weather(city: str, runtime: ToolRuntime) -> Command:  # 因为调用了ToolNode，没有工具节点，但是我想更新State，可以使用Command + ToolRuntime的方法实现
    """
    查询指定城市的当日天气

    Args:
        city: 要查询天气的城市名称，如"北京"、"上海"

    Returns:
        该城市的当日天气描述
    """
    res = f"{city} 当日的天气为晴朗"
    tool_call_id = runtime.tool_call_id
    tool_msg = ToolMessage(name="get_weather", content=res, tool_call_id=tool_call_id)
    return Command(
        update={"weather_result": res,
                "messages": [tool_msg]}
    )


@tool(parse_docstring=True)
def get_news(home_or_abroad: bool, runtime: ToolRuntime) -> Command:
    """
    查询国内外的新闻

    Args:
        home_or_abroad: 查询国内或者国外的新闻 True:国内新闻 False:国外新闻
    """
    if home_or_abroad:
        res = "Kimi 新模型发布"
    else:
        res = "Anthropic 暂停模型访问"
    tool_call_id = runtime.tool_call_id
    tool_msg = ToolMessage(name="get_news", content=res, tool_call_id=tool_call_id)
    return Command(
        update={"news_result": res,
                "messages": [tool_msg]}
    )



# 模型绑定工具
tools_by_name = {
    "get_weather": get_weather,
    "get_news": get_news
}

tools = [get_weather, get_news]

model_with_tools = model.bind_tools(tools=tools)


# 3. 声明状态 -> 传入的时候 直接写入HumanMessage
class OverAllState(MessagesState):
    weather_result: str  # 天气结果
    news_result: str  # 新闻结果
    output: str  # 最终输出


# 4. 定义节点
def llm_node(state: OverAllState) -> OverAllState:
    msg = state["messages"]
    # 调用大模型
    res = model_with_tools.invoke(msg)
    return {
        "messages": [res],
        "output": res.content
    }



def router(state: OverAllState) -> Literal["tool_node", END]:
    if state["messages"][-1].tool_calls:
        return "tool_node"
    return END


# 5. 构建图
builder = StateGraph(state_schema=OverAllState)
builder.add_node("llm_node", llm_node)
# builder.add_node("tool_node", tool_node)  # 不要手动定义工具节点, 因为ToolNode会自动处理工具调用
builder.add_node("tool_node", ToolNode(tools=tools))  # 此处调用ToolNode, 会自动处理工具调用       好用!!!!!!!!!!!!!!!!!!!!!!!!!!!

builder.add_edge(START, "llm_node")
builder.add_conditional_edges("llm_node", router, path_map=["tool_node", END])
builder.add_edge("tool_node", "llm_node")

graph = builder.compile()

res = graph.invoke({"messages": [HumanMessage(content="查询一下今天上海的天气,和国外的新闻")]})
print(res)
print("*"*100)

for msg in res["messages"]:
    msg.pretty_print()