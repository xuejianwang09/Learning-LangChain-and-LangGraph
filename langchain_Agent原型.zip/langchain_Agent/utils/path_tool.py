"""
为整个工程提供统一的绝对路径
"""
import os


def get_project_root() -> str:
    """
    获取工程的根目录
    :return:字符串
    """
    current_file = os.path.abspath(__file__)
    curProjectRoot = os.path.dirname(os.path.dirname(current_file))  # 向上两级就是工程的目录
    return curProjectRoot


def get_abs_path(relative_path: str) -> str:
    """
    传递相对路径，返回绝对路径
    :param relative_path:
    :return:
    """
    curProjectRoot = get_project_root()
    return os.path.join(curProjectRoot, relative_path)


if __name__ == '__main__':
    print(get_abs_path("config/config.txt"))
