"""
用于向量存储,包含加载指定目录下的所有文件，通过校验md5判断文件是否已经存入数据库
未存入数据库的进行文本分割后存入数据库
VectorStoreService是对象，需要创建
可以使用load_document加载数据
可以使用get_retriever来检索数据库内容
"""
import os
from langchain_chroma import Chroma
from utils.config_handler import chroma_conf
from model.factory import embed_model
from langchain_text_splitters import RecursiveCharacterTextSplitter
from utils.path_tool import get_abs_path
from utils.file_handler import pdf_loader, txt_loader, listdir_with_allowed_type, get_file_md5_hex
from utils.logger_handler import logger


class VectorStoreService(object):
    def __init__(self):
        self.vector_store = Chroma(
            collection_name=chroma_conf["collection_name"],
            embedding_function=embed_model,
            persist_directory=get_abs_path(chroma_conf["persist_directory"]),  # chroma的存储路径
        )
        self.spliter = RecursiveCharacterTextSplitter(  # 文本分割器
            chunk_size=chroma_conf["chunk_size"],
            chunk_overlap=chroma_conf["chunk_overlap"],
            separators=chroma_conf["separators"],
            length_function=len,
        )

    def get_retriever(self):
        """返回向量检索器"""
        return self.vector_store.as_retriever(search_kwargs={"k": chroma_conf["k"]})

    def load_document(self):
        """
        从数据文件夹内读取数据文件，转为向量存入向量库   不需要指定文件，文件夹写死了
        要计算文件的md5，加载过的文件不处理了
        :return:
        """

        def check_md5_hex(md5_for_check: str):
            if not os.path.exists(get_abs_path(chroma_conf["md5_hex_store"])):
                open(get_abs_path(chroma_conf["md5_hex_store"]), "w", encoding="utf-8").close()
                return False

            with open(get_abs_path(chroma_conf["md5_hex_store"]), "r", encoding="utf-8") as f:
                for line in f.readlines():
                    line = line.strip()  # 去掉字符串 line 两端的所有空白字符（空格、换行符、制表符等）
                    if line == md5_for_check:
                        return True

                return False

        def save_md5_hex(md5_for_check: str):
            """保存 MD5 校验值"""
            with open(get_abs_path(chroma_conf["md5_hex_store"]), "a", encoding="utf-8") as f:
                f.write(md5_for_check + "\n")

        def get_file_documents(read_path: str) -> list[str]:
            """根据文件后缀分发加载器"""
            if read_path.endswith(".txt"):
                return txt_loader(read_path)

            if read_path.endswith(".pdf"):
                return pdf_loader(read_path)

            return []

        allow_files_path: list[str] = listdir_with_allowed_type(
            get_abs_path(chroma_conf["data_path"]),
            tuple(chroma_conf["allow_knowledge_file_type"])
        )
        for path in allow_files_path:
            md5 = get_file_md5_hex(path)
            if check_md5_hex(md5):
                logger.info(f"[加载知识库]{path}已经存在知识库[跳过]")
                continue
            # 此前没有导入，进行分割 导入向量库
            try:
                documemt = get_file_documents(path)
                if not documemt:
                    logger.warning(f"[加载知识库]{path}文本内无内容")
                    continue

                split_document = self.spliter.split_documents(documemt)

                if not split_document:
                    logger.warning(f"[加载知识库]{path}无法分割出有效内容")
                    continue

                self.vector_store.add_documents(split_document)  # 存储进入向量库

                save_md5_hex(md5)  # 保存文件的md5
                logger.info(f"{path}加载知识库成功")
            except Exception as e:
                # exc_info=True 的作用是：把完整的异常堆栈信息（traceback）一起记录到日志里。
                logger.error(f"{path}加载知识库失败：{str(e)}", exc_info=True)


if __name__ == '__main__':
    vs = VectorStoreService()
    vs.load_document()  # 加载data里面所有的文件
    retriever = vs.get_retriever()  # 获取向量检索器
    res = retriever.invoke("设备工位是什么")
    for r in res:
        print(r.page_content)
        print("*" * 20)

