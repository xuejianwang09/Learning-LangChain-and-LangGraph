from typing import Literal
from langchain_core.messages import HumanMessage, ToolMessage
from langgraph.graph import StateGraph, START, END, MessagesState
from langgraph.types import Command, interrupt
from src.agent import agent
from langgraph.checkpoint.memory import InMemorySaver


# ===================== State =====================
class OverAllState(MessagesState):
    """
    MessagesState 已经包含：
        messages: Annotated[list, add_messages]

    这里只追加你自己的业务字段
    """
    input_query: str
    output_result: str
    is_approved: str


# ===================== 节点 =====================
def approve_node(
    state: OverAllState,
) -> Command[Literal["llm_node", "default_node"]]:
    """
    HITL 审批节点
    让AgentChatUi渲染中断信息  必须按格式写
    从 messages 中获取用户输入并保存到 input_query
    因为AgentChatUi只认messages，不管自己定义的input_query、output_result、is_approved三个变量  ui输入的内容只会在messages里，不会主动赋值三个变量
    """
    messages = state.get("messages", [])
    input_query = None
    for msg in reversed(messages):
        if isinstance(msg, HumanMessage):
            input_query = msg.content
            break
    
    if not input_query:
        input_query = "你好"
    
    resume_value = interrupt({
        "action_requests": [
            {
                "name": "llm_use",
                "args": {},
                "description": "是否允许调用LLM?",
            }
        ],
        "review_configs": [
            {
                "action_name": "llm_use",
                "allowed_decisions": [
                    "approve",
                    "reject",
                ],
            }
        ],
    })

    # AgentChatUI 返回的格式: {'decisions': [{'type': 'approve'}]} 或 {'decisions': [{'type': 'reject'}]}
    print(f"=== DEBUG: resume_value = {resume_value} ===")
    print(f"=== DEBUG: type = {type(resume_value)} ===")
    
    # 解析 AgentChatUI 返回的 decisions 格式
    if isinstance(resume_value, dict) and "decisions" in resume_value:
        decisions = resume_value.get("decisions", [])
        decision = decisions[0].get("type") if decisions else None
    elif isinstance(resume_value, dict):
        decision = resume_value.get("llm_use")
    else:
        decision = resume_value
    
    print(f"=== DEBUG: decision = {decision} ===")

    if decision == "approve":
        return Command(
            goto="llm_node",
            update={
                "is_approved": "approve",
                "input_query": input_query,  # 保存用户输入
            },
        )
    else:
        return Command(
            goto="default_node",
            update={
                "is_approved": "reject",
                "input_query": input_query,  # 保存用户输入
            },
        )


def llm_node(state: OverAllState) -> dict:
    input_query = state.get("input_query", "你好")
    
    response = agent.invoke({"messages": [HumanMessage(input_query)]})
    # 获取最后一个消息（最新回复）
    latest_message = response["messages"][-1]
    return {
        "messages": [
                    HumanMessage(input_query),
                    latest_message,
                    ],  # 把用户的提问与AI的回答都记录到messages
        "output_result": latest_message.content,
    }


def default_node(state: OverAllState) -> dict:
    return {
        "messages": [
            HumanMessage(content="请求被拒绝了")
        ],
        "output_result": "请求被拒绝了",
    }


def output_node(state: OverAllState) -> dict:
    """
    最终输出节点（可做日志、格式化等）
    """
    return {
        "output_result": state["output_result"],
    }


# ===================== 构图 =====================
builder = StateGraph(OverAllState)

builder.add_node("approve_node", approve_node)
builder.add_node("llm_node", llm_node)
builder.add_node("default_node", default_node)
builder.add_node("output_node", output_node)

builder.add_edge(START, "approve_node")
builder.add_edge("llm_node", "output_node")
builder.add_edge("default_node", "output_node")
builder.add_edge("output_node", END)


chat_graph = builder.compile()
# 为什么这里使用langsmith dev运行，中断不需要添加checkpoint
# langgraph dev 之所以能“恢复”这个中断，是因为它背后已经自动帮你用了 checkpoint
# 但如果你自己写脚本 graph.invoke(...)，不传 checkpointer 是会报错的