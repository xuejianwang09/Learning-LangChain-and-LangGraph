from typing import TypedDict
from langgraph.graph import StateGraph, START, END


# ==================== 子图 ====================
class SubgraphState(TypedDict):
    raw_text: str
    stripped_text: str
    punctuated: str


def subgraph_strip_node(state: SubgraphState) -> SubgraphState:
    print("正在调用子图节点 subgraph_strip_node")
    return {
        "stripped_text": state["raw_text"].strip()
    }


def subgraph_punctuate_node(state: SubgraphState) -> SubgraphState:
    print("正在调用子图节点 subgraph_punctuate_node")
    return {
        "punctuated": state["stripped_text"] + "."
    }


subgraph_builder = StateGraph(SubgraphState)
subgraph_builder.add_node("strip", subgraph_strip_node)
subgraph_builder.add_node("punctuate", subgraph_punctuate_node)
subgraph_builder.add_edge(START, "strip")
subgraph_builder.add_edge("strip", "punctuate")
subgraph_builder.add_edge("punctuate", END)

subgraph_graph = subgraph_builder.compile()


# ==================== 父图 ====================
class ParentState(TypedDict):
    input_text: str
    raw_text: str
    stripped_text: str
    punctuated: str
    output_text: str


def prepare_subgraph_input(state: ParentState) -> ParentState:
    print("正在调用父图节点 prepare_subgraph_input")
    return {
        "raw_text": state["input_text"]
    }


def finalize_output(state: ParentState) -> ParentState:
    print("正在调用父图节点 finalize_output")
    return {
        "output_text": state["punctuated"]
    }


parent_builder = StateGraph(ParentState)

# 子图作为节点直接挂进来
parent_builder.add_node("prepare_input", prepare_subgraph_input)
parent_builder.add_node("text_processor", subgraph_graph)  # ✅ 关键改动！！！！！！！！！！！！！！！
parent_builder.add_node("finalize_output", finalize_output)

parent_builder.add_edge(START, "prepare_input")
parent_builder.add_edge("prepare_input", "text_processor")
parent_builder.add_edge("text_processor", "finalize_output")
parent_builder.add_edge("finalize_output", END)

parent_graph = parent_builder.compile()


# ==================== 运行 ====================
res = parent_graph.invoke({
    "input_text": " 你好, 我是JM啊啊啊啊啊啊啊  "
})
print(res)


png_bytes = parent_graph.get_graph(xray=True).draw_mermaid_png()   # 添加xray=True可以查看子图的节点！！！！！！！！！！！！！！
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")