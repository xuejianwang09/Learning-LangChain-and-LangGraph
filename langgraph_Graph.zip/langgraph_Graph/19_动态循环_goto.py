from idlelib.undo import Command

from langchain_core.messages import HumanMessage, ToolMessage, SystemMessage
from langgraph.graph import StateGraph, START, END
from typing import TypedDict, Literal
from langgraph.types import Send, Command
from langgraph.graph.message import MessagesState
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
import random

from sympy.codegen.cnodes import goto

model = ChatOpenAI(
    model="qwen3.7-plus",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7,
)


# 1. 定义工具
@tool(description="根据姓名获取体重，返回值是整数，单位千克")
def get_weight(name: str) -> int:
    """
    根据姓名查询体重

    Args:
        name (str): 人员姓名
    """
    # 实际场景中这里会查数据库
    if name == "JM":
        return 88
    else:
        return 90


@tool(description="根据姓名获取身高，返回值是整数，单位千克")
def get_height(name: str) -> int:
    """
    根据姓名查询身高

    Args:
        name (str): 人员姓名
    """
    # 实际场景中这里会查数据库
    if name == "JM":
        return 180
    else:
        return 166

# 绑定工具
model_with_tools = model.bind_tools([get_weight, get_height])
# res = model_with_tools.invoke("你好，我想知道我的体重和身高是多少")  # 没有循环无法调用工具，只能调用一次工具
# print(res)

"""
因为 OverAllState 继承了 MessagesState，而 MessagesState 里的 messages 使用了 add_messages reducer，所以“即使你没显式初始化，也能追加”。
"""
class OverAllState(MessagesState):  # MessagesState内部使用的是add_messages方法，根据id来判断是否覆盖还是追加
    user_input: str
    final_output: str

def input_node(state: OverAllState) -> OverAllState:
    return {
        "messages": [HumanMessage(content=state['user_input'])],
    }

def llm_node(state: OverAllState) ->Command[Literal["tool_node", "output_node"]]:
    # 使用goto完成动态循环  直到没有工具调用
    ai_mes = model_with_tools.invoke(state["messages"])
    if ai_mes.tool_calls:
        goto="tool_node"
    else:
        goto="output_node"
    return Command(
        update={
        "messages": [ai_mes]
        },
        goto = goto
    )

# 判断是否需要调用工具
def tool_node(state: OverAllState) -> OverAllState:
    messages = state["messages"]  # 拿到当前的messages 并取出最近一条消息  即当前的LLM回答
    ai_mes = messages[-1]
    tool_calls = ai_mes.tool_calls  # ****************获取LLM 返回的 tool_call  包含工具调用的参数 可直接传入工具函数
    fail_prob = 6  # 失败的概率

    for tool_call in tool_calls:
        if tool_call["name"] == "get_weight":
            #生成0-9判断大小
            if random.randint(0,9) < fail_prob:
                messages.append(ToolMessage(
                    content="网络波动，调用失败，请重试",
                    tool_call_id = tool_call["id"]
                ))
            else:
                messages.append(get_weight.invoke(tool_call))

        elif tool_call["name"] == "get_height":
            # 生成0-9判断大小
            if random.randint(0, 9) < fail_prob:
                messages.append(ToolMessage(
                    content="网络波动，调用失败，请重试",
                    tool_call_id=tool_call["id"]
                ))
            else:
                messages.append(get_height.invoke(tool_call))

    return {
        "messages":messages  # llm_node中因为res的id是新的所以追加，但是tool_node中的messages的id已经在messages中存在，所以是覆盖写而不是追加
    }

# 最后输出
def output_node(state: OverAllState) -> OverAllState:
    return {
        "final_output":state["messages"][-1].content
    }



## 4. 构建图
builder = StateGraph(OverAllState)
builder.add_node("input_node", input_node)
builder.add_node("llm_node", llm_node)
builder.add_node("tool_node",tool_node)
builder.add_node("output_node",output_node)

builder.add_edge(START, "input_node")
builder.add_edge("input_node", "llm_node")  # 动态循环的边  不需要router，直接在llm_node中判断是否需要调用工具
builder.add_edge("tool_node", "llm_node")
builder.add_edge("output_node", END)

"""
send 不是一条“边”，而是一个“动态生成边的指令”；它本身不执行、不占节点、不出现在图的拓扑中，因此它是虚边
"""

# 5. 编译运行
graph = builder.compile()
result = graph.invoke({
    "user_input": "查询一下我(JM)当前的身高和体重分别是多少",
    "messages": [SystemMessage("如果工具调用失败，必须重新调用，一直到成功为止")]
})

print("user_input",result["user_input"])
print("final_output",result["final_output"])
for msg in result["messages"]:
    msg.pretty_print()

# 7.保存图片
png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")