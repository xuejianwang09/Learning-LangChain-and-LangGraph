from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, START, END
from langgraph.types import Send, Command
from langgraph.graph.message import MessagesState
from langchain_openai import ChatOpenAI
from typing import TypedDict, Literal, Sequence

model = ChatOpenAI(
    model="qwen3.7-plus",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7,
)

class OverAllState(MessagesState):  # MessagesState内部使用的是add_messages方法，根据id来判断是否覆盖还是追加
    topic: str
    poem: str
    joke: str
    content_type: Literal["poem", "joke"]
    content_Chinese: str

def router(state:OverAllState) -> Command[Literal["poem_node", "joke_node", "__end__"]]:
    if state["content_type"] == "poem":
        return Command(
            update={
                "content_Chinese": "一首诗"
            },
            goto="poem_node"
        )
    elif state["content_type"] == "joke":
        return Command(
            update={
                "content_Chinese": "一个笑话"
            },
            goto="joke_node"
        )
    else:
        return Command(goto="__end__")

def poem_node(state: OverAllState) -> OverAllState:
    res = model.invoke(f"写一首关于{state['topic']}的诗")
    return {
        "poem": res.content,
    }

def joke_node(state: OverAllState) -> OverAllState:
    res = model.invoke(f"写一个关于{state['topic']}的笑话")
    return {
        "joke": res.content,
    }

def print_node(state: OverAllState) -> OverAllState:
    print("*"*10 + state["content_Chinese"])
    return state

# 4. 构建图
builder = StateGraph(state_schema=OverAllState)

builder.add_node("router_node", router)
builder.add_node("poem_node", poem_node)
builder.add_node("joke_node", joke_node)
builder.add_node("print_node", print_node)

builder.add_edge(START, "router_node")
builder.add_edge("poem_node", "print_node")
builder.add_edge("joke_node", "print_node")
builder.add_edge("print_node", END)



# 5. 编译运行
graph = builder.compile()
result = graph.invoke({"topic": "荷花", "content_type": "poem"})
print(result)

print("*"*50)

result = graph.invoke({"topic": "荷花", "content_type": "joke"})
print(result)

print("*"*50)

result = graph.invoke({"topic": "荷花", "content_type": "xxx"})
print(result)


# 7.保存图片
png_bytes = graph.get_graph().draw_mermaid_png()
with open("mermaid_graph.png", "wb") as f:
    f.write(png_bytes)
print("图片已保存为 mermaid_graph.png")