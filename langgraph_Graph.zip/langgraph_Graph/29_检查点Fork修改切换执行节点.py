
from typing import TypedDict, Annotated, Literal
from langchain.messages import SystemMessage, HumanMessage, AIMessage
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.graph import StateGraph, START, END
from langchain_openai import ChatOpenAI
from pydantic import BaseModel, Field
from starlette.routing import Router

model = ChatOpenAI(
    model="qwen3-max-preview",
    api_key="sk-ws-H.EMMPPML.Nfdj.MEUCIQDsRDXH2xypr-GqBcaIB_bY0IyPi2PdaGDiacv8UyYqZgIgLfzBV_z5utppgJF9OL5MUlnEkzcXNo1qDEZq-V2s_cE",
    base_url="https://ws-rcodnqgshc6earzw.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
    temperature=0.7,
    extra_body={
        "enable_thinking": False,  # 硬关思考链（Qwen 混合模型标准开关）
        # "reasoning": {"effort": "none"},  # 新接口也可用这个，二选一
    },
)


class OverAllState(TypedDict):
    username: str
    user_input: str
    output: str

class StructuredOutputState(TypedDict):
    topic: str = Field(
        ...,
        description="主题关键词，仅限1~4个字，如：猫、狗",
        examples=["猫", "狗"]
    )
    mode: Literal["poem", "joke"] = Field(
        ...,
        description="输出类型：诗→poem，笑话→joke"
    )


model_with_structure = model.with_structured_output(schema=StructuredOutputState)  # 现在可以返回结构化输出  有些模型（特别是通过兼容 API 调用的）可能不完全支持 function calling / structured output

# 声明节点
def router_node(state: OverAllState) -> StructuredOutputState:
    print("路由节点已经运行")
    res = model_with_structure.invoke(
        [HumanMessage(state["user_input"])]
    )
    print(f"路由结果为{res}")
    return res


def router(state: StructuredOutputState) -> Literal["node_poem", "node_joke", "node_default"]:
    print("路由函数已经运行")
    if state["mode"] == "poem":
        print("----------------------模式为poem")
        return "node_poem"
    elif state["mode"] == "joke":
        print("----------------------模式为joke")
        return "node_joke"
    else:
        print("----------------------模式未知")
        return "node_default"

def node_poem(state: StructuredOutputState) -> OverAllState:
    print("node_poem节点已经运行")
    poem = model.invoke(
        [HumanMessage("请写一首关于" + state["topic"] + "的诗")]
    )
    return {
        "output": poem,
    }

def node_joke(state: StructuredOutputState) -> OverAllState:
    print("node_joke节点已经运行")
    joke = model.invoke(
        [HumanMessage("请写一个关于" + state["topic"] + "的笑话，字数在100以内")]
    )
    return {
        "output": joke,
    }

def node_default(state: StructuredOutputState) -> OverAllState:
    print("node_default节点已经运行")
    return {
        "output": "无法处理任务请求！！！",
    }

# 构建图
builder = StateGraph(state_schema=OverAllState)
builder.add_node(router_node)
builder.add_node(node_poem)
builder.add_node(node_joke)
builder.add_node(node_default)

builder.add_edge(START, "router_node")
builder.add_conditional_edges("router_node", router,path_map={
    "node_poem": "node_poem",
    "node_joke": "node_joke",
    "node_default": "node_default",
})
builder.add_edge("node_joke", END)
builder.add_edge("node_default", END)
builder.add_edge("node_poem", END)

# 配置检查点
DB_URL = "postgresql://my_langgraph_user:123456@localhost:5432/langgraph_db?sslmode=disable"
with PostgresSaver.from_conn_string(DB_URL) as checkpointer:  # 第一次使用 需要setup数据库
    graph = builder.compile(checkpointer = checkpointer)

    # 配置线程id
    config = {
        "configurable":{
            "thread_id":"TEST032"
        }
    }
    result = graph.invoke({"username": "JM","user_input": "写一首关于猫的诗"},config = config)
    print(result)


    print("-----------------")
    # 查看历史检查点 get_state_history
    history_checkpoints2 = list(graph.get_state_history(config))
    print(history_checkpoints2)

    print("-----------------")
    #获取某一个节点的检查点
    new_checkpoints = None
    for checkpoint in history_checkpoints2:
        if checkpoint.next == ('router_node',):
            new_checkpoints = checkpoint
            break


    """
    改变new_checkpoints的value
    """
    change_input = graph.update_state(
        config=new_checkpoints.config,
        values={"user_input": "写一首关于狗的笑话"},
        as_node=START,
    )

    result = graph.invoke(None,config = change_input)
    print(result)

    """
    改变new_checkpoints的value
    选哪个 checkpoint（通过 config 里的 checkpoint_id）决定了 update_state 从哪一棵“历史树节点”上fork 出新分支，
    而as_node 只决定这个新分支的 next 怎么算。两者是不同维度，但会叠加生效  
    as_node甚至可以选择后面的节点  但 后果你要自己兜住
    """
    # change_input = graph.update_state(
    #     config=new_checkpoints.config,
    #     values={"topic": "狸花猫","mode": "null"},
    #     as_node="router_node",  # 假装 router_node 刚刚执行完，并且写出了这些 state   实际并没有执行router_node，只是修改了state  所以没有打印：路由节点已经运行
    # )
    #
    # result = graph.invoke(None,config = change_input)
    # print(result)
