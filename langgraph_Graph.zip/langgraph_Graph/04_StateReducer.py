from typing import TypedDict, Annotated
from langgraph.graph import StateGraph, START, END

# 1. 自定义 reducer 函数
# left: 从开始位置合并到当前节点的值
# right: 当前节点的值
# 返回值: 合并后的值
def my_reducer(left: list[str], right: list[str]) -> list[str]:
    return left + right

# 2. 定义状态，使用 Annotated 指定 reducer
class OverAllState(TypedDict):
    logs: Annotated[list[str], my_reducer]  # 使用自定义 reducer 合并日志  与add效果一致

# 3. 定义节点
def node_1(state: OverAllState) -> OverAllState:
    return {"logs": ["node_1 运行完毕"]}

def node_2(state: OverAllState) -> OverAllState:
    return {"logs": ["node_2 运行完毕"]}

# 4. 构建图
builder = StateGraph(state_schema=OverAllState)
builder.add_node(node_1)
builder.add_node(node_2)
builder.add_edge(START, "node_1")
builder.add_edge("node_1", "node_2")
builder.add_edge("node_2", END)

# 5. 编译并运行
graph = builder.compile()
result = graph.invoke({"logs": ["start"]})
# print(result)

# 6. 演示 reducer 合并过程
# 模拟合并过程
left = ["start", "node_1 运行完毕...."]
right = ["node_2 运行完毕...."]
merged = my_reducer(left, right)
print(merged)